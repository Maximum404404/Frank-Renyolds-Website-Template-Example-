<!DOCTYPE html>
    <head>
        <title> Frank The Buisnessman </title>
		
		<style>
		* {
		  box-sizing: border-box;
		}

		.column {
		  float: left;
		  width: 33.33%;
		  padding: 5px;
		}

		/* Clearfix (clear floats) */
		.row::after {
		  content: "";
		  clear: both;
		  display: table;
		}
		

	h1 {
		color: black;
		font-family: Courier, Trattatello;
		font-size: 100%;
		font-style: italic;
	}
	
		h1 {
		color: black;
		font-family: Courier, Trattatello;
		font-size: 300%;
		font-style: italic;
	}
	
	h2 {
		color: black;
		font-family: Courier, monospace;
		font-size: 175%;
		font-style: italic;
	}
	
	p {
		color: black;
		font-family: Verdana;
		font-size: 100%;
		font-style: normal;
	}
	
	a {
		color: red;
		font-family: Verdana;
		font-size: 100%;
		font-style: italic;
		</style>

    </head>

	
	
	  <body>
	  <h1>FRANK RENYOLDS MONEY</h1>
	  <h2>SEXIEST AND RICHEST MAN ALIVE</h2>
	  <p>Here Are Some Items I Am Selling You</p>


		<div class="row">
		  <div class="column">
			<a href= "Frank_ItemInCart.html">  <img src="Images/EggSell.jpg" alt="Franks egg you can buy" style="width:500px;height:600px;"> </a>
				<!-- This image links to an external page which is the stand in for a basket funtion, and will activate when clicked -->
				<p style="text-align:center;">Click Image To Buy Item</p>
		  </div>
		  <div class="column">
			<a href= "Frank_ItemInCart.html"> <img src="Images/DannyCutOut.jpg" alt="Franks personal soda company" style="width:500px;height:600px;"> </a>
				<!-- This image links to an external page which is the stand in for a basket funtion, and will activate when clicked -->
				<p style="text-align:center;">Click Image To Buy Item</p>
		  </div>
		  <div class="column">
			<a href= "Frank_ItemInCart.html"> <img src="Images/WolfCola.jpg" alt="Frank Image 2" style="width:500px;height:600px;"> </a>
				<!-- This image links to an external page which is the stand in for a basket funtion, and will activate when clicked -->
				<p style="text-align:center;">Click Image To Buy Item</p>
		  </div>
		</div>



				<p style = 'margin: 0;'>&nbsp;</p>
				<p style = 'margin: 0;'>&nbsp;</p>
				<p style = 'margin: 0;'>&nbsp;</p>
				<p>		Here are links to the rest of my site </p>
				<!-- The next bit of code is for the navigation -->
			  <a href="https://www.youtube.com/watch?v=gOR8VI-5_vI">Best Of Me, Frank Reynolds</a>
				  <p> </p>
			  <a href='Frank_My_Buisness_and_How_Rich_I_Am.html'> How Rich Am I?</a>
					  <p> </p>

			  <a href='Frank_My_Friends.html'> My Friends </a>
					  <p> </p>

			  <a href='Frank_Images_Page.html'> Frank's Gallery </a>
					  <p> </p>

			  <a href='Frank_WhereIWork_Page.html'> Where Do I Work? </a>
					  <p> </p>

			  <a href='index.html'> Homepage </a>
					  <p> </p>
			<div>
			</div>

	</body>
</html>	  