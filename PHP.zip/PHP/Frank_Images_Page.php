<!DOCTYPE html>
    <head>
        <title> Frank's Gallery </title>
		<!-- Page name -->
		
			<style>
		* {
		  box-sizing: border-box;
		}

		.column {
		  float: left;
		  width: 33.33%;
		  padding: 5px;
		}

		/* Clearfix (clear floats) */
		.row::after {
		  content: "";
		  clear: both;
		  display: table;
		}
		
		h1 {
			color: black;
			font-family: Courier, Trattatello;
			font-size: 100%;
			font-style: italic;
		}
		
			h1 {
			color: black;
			font-family: Courier, Trattatello;
			font-size: 300%;
			font-style: italic;
		}
		
		h2 {
			color: black;
			font-family: Courier, monospace;
			font-size: 175%;
			font-style: italic;
		}
		
		p {
			color: black;
			font-family: Verdana;
			font-size: 100%;
			font-style: normal;
		}
		
		a {
			color: red;
			font-family: Verdana;
			font-size: 100%;
			font-style: italic;
		}
		</style>
    </head>

	
		<!-- In this collection of code, i have allinged spefic photos side by side in the same style as a yearbook page, each photo is would have text describing the images -->

	
	<body>
	  Images Of Frank
	  <!-- Page description -->
	  <h1>PHOTOS OF ME, FRANK RENYOLDS</h1>
	  <h2>SEXIEST AND RICHEST MAN ALIVE</h2>

	  <p>INSERT BASIC PHOTOS HERE</p>


					<!-- Here is the first row of images -->
		<div class="row">
		  <div class="column">
			<img src="Images/5.jpg" alt="Frank Image 1" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/5x8_Paddys_Egg.png" alt="Frank Image 2" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/47539c3a2740f280-600x338.jpg" alt="Frank Image 3" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		</div>
			
					<!-- Here is the second row of images -->
		<div class="row">
		  <div class="column">
			<img src="Images/190325-danny-devito-featured.jpg" alt="Frank Image 4" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/frank-heather-perry.jpg" alt="Frank Image 5" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/frank-reynolds-c08a6280-fd53-4df6-925a-a707f57fff3-resize-750.jpeg" alt="Frank Image 6" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		</div>


					<!-- Here is the Third row of images -->
		<div class="row">
		  <div class="column">
			<img src="Images/It's_Always_Sunny_in_Philadelphia_-_Frank_Reynolds_on_the_gun_controversy_-_FULL_SCENE_0-43_screenshot.png" alt="Frank Image 7" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/maxresdefault.jpg" alt="Frank Image 8" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/ppW_-8TxxWSl.jpg" alt="Frank Image 9" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		</div>

		<div class="row">
		  <div class="column">
			<img src="Images/sjuwd4svl4x11.jpg" alt="Frank Image 10" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/Square-Frank-Cheesy.jpg" alt="Frank Image 11" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		  <div class="column">
			<img src="Images/unnamed.jpg" alt="Frank Image 12" style="width:100%">
			<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
		  </div>
		</div>




				<p>		Here are links to the rest of my site </p>
				<!-- The next bit of code is for the navigation -->
			  <a href="https://www.youtube.com/watch?v=gOR8VI-5_vI">Best Of Me, Frank Reynolds</a>
				  <p> </p>
			  <a href='Frank_My_Buisness_and_How_Rich_I_Am.html'> How Rich Am I?</a>
					  <p> </p>

			  <a href='Frank_My_Friends.html'> My Friends </a>
					  <p> </p>

			  <a href='Frank_Images_Page.html'> Frank's Gallery </a>
					  <p> </p>

			  <a href='Frank_WhereIWork_Page.html'> Where Do I Work? </a>
					  <p> </p>

			  <a href='index.html'> Homepage </a>
					  <p> </p>
	</body>
</html>	  