<!DOCTYPE html>
    <head>
        <title> Purchase Page</title>
		<!-- Page name -->

    </head>

	<style>


	h1 {
		color: black;
		font-family: Courier, Trattatello;
		font-size: 100%;
		font-style: italic;
	}
	
		h1 {
		color: black;
		font-family: Courier, Trattatello;
		font-size: 300%;
		font-style: italic;
	}
	
	h2 {
		color: black;
		font-family: Courier, monospace;
		font-size: 175%;
		font-style: italic;
	}
	
	p {
		color: black;
		font-family: Verdana;
		font-size: 100%;
		font-style: normal;
	}
	
	a {
		color: red;
		font-family: Verdana;
		font-size: 100%;
		font-style: italic;
	}
	
	
	</style>
	
	  <body>
	  <h1>FRANK RENYOLDS MONEY</h1>
	  <h2>SEXIEST AND RICHEST MAN ALIVE</h2>
	  <p>Here Is Your Basket</p>
	  
		<!-- Just a fake basket page with the image as a stand in -->
    <img src="Images/cart.png" alt="fake cart" style="width:100%">
	
	




		<p>		Here are links to the rest of my site </p>
		<!-- The next bit of code is for the navigation -->
	  <a href="https://www.youtube.com/watch?v=gOR8VI-5_vI">Best Of Me, Frank Reynolds</a>
	  	  <p> </p>
	  <a href='Frank_My_Buisness_and_How_Rich_I_Am.html'> How Rich Am I?</a>
	  	  	  <p> </p>

	  <a href='Frank_My_Friends.html'> My Friends </a>
	  	  	  <p> </p>

	  <a href='Frank_Images_Page.html'> Frank's Gallery </a>
	  	  	  <p> </p>

	  <a href='Frank_WhereIWork_Page.html'> Where Do I Work? </a>
	  	  	  <p> </p>

	  <a href='index.html'> Homepage </a>
	  	  	  <p> </p>
	</body>
</html>	  