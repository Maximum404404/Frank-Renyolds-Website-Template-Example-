<!DOCTYPE html>
    <head>
        <title> Frank's Mates </title>
<!-- Here is the code used for getting the boxes side by side in this page -->

					<style>
					* {
					  box-sizing: border-box;
					}

					.column {
					  float: left;
					  width: 33.33%;
					  padding: 5px;
					}

					/* Clearfix (clear floats) */
					.row::after {
					  content: "";
					  clear: both;
					  display: table;
					}
					
					h1 {
						color: black;
						font-family: Courier, Trattatello;
						font-size: 100%;
						font-style: italic;
					}
					
						h1 {
						color: black;
						font-family: Courier, Trattatello;
						font-size: 300%;
						font-style: italic;
					}


					p {
						color: black;
						font-family: Verdana;
						font-size: 100%;
						font-style: normal;
					}
					
					a {
						color: red;
						font-family: Verdana;
						font-size: 100%;
						font-style: italic;
					</style>
    </head>

	
	
			  <body>
					<h1>FRANK RENYOLDS</h1>
					<p>Here is my asscotiates</p>
					<img src="Images/Gang.png" alt="Gang">
					<!-- Here is a basic photo of the cast of the show -->

					<p>LorenIpsum LorenipsumLorenIpsum LorenipsumLorenIpsum Lorenipsum</p>
					<h1>Here Is The Rest Of The Gang In Their Own Rights</h1>
					
					



				<div id="images">
					<img src="Images/5.jpg" alt="Frank">
					<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<img src="Images/Dennis.jpg" alt="Dennis">
					<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<img src="Images/Mac.jpeg" alt="Mac">
					<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
					<img src="Images/Charlie.jpg" alt="Charile">
					<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<img src="Images/Dee.jpg" alt="Dee">
					<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				</div>




					<!-- THese also are used to put the images side by side -->


				<div class="row">
				  <div class="column">
					<img src="Images/Dennis.jpg" alt="Dennis" style="width:100%">
					<img src="Images/Dee.jpg" alt="Dee" style="width:100%">
				  </div>
				  <div class="column">
					<img src="Images/5.jpg" alt="Frank" style="width:100%">
					<img src="Images/Mac.jpeg" alt="Mac" style="width:100%">
				  </div>
				  <div class="column">
					<img src="Images/Charlie.jpg" alt="Charile" style="width:100%">
				  </div>
				</div>



		<p>		Here are links to the rest of my site </p>
		<!-- The next bit of code is for the navigation -->
	  <a href="https://www.youtube.com/watch?v=gOR8VI-5_vI">Best Of Me, Frank Reynolds</a>
	  	  <p> </p>
	  <a href='Frank_My_Buisness_and_How_Rich_I_Am.html'> How Rich Am I?</a>
	  	  	  <p> </p>

	  <a href='Frank_My_Friends.html'> My Friends </a>
	  	  	  <p> </p>

	  <a href='Frank_Images_Page.html'> Frank's Gallery </a>
	  	  	  <p> </p>

	  <a href='Frank_WhereIWork_Page.html'> Where Do I Work? </a>
	  	  	  <p> </p>

	  <a href='index.html'> Homepage </a>
	  	  	  <p> </p>
	</body>
</html>	  